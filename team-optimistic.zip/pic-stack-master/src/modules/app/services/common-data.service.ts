import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonDataService 
{
  //private baseUrl= 'http://10.217.15.13:8000/'; //naveen
  private baseUrl= 'http://localhost::8000/'; //local 

  getBaseURL()
  {
    return this.baseUrl;
  }

  constructor() { }
}
