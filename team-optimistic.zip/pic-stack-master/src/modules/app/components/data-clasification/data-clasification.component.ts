import { Component, OnInit } from '@angular/core';
import { CommonDataService } from '../../services/common-data.service';

@Component({
  selector: 'app-data-clasification',
  templateUrl: './data-clasification.component.html',
  styleUrls: ['./data-clasification.component.scss']
})
export class DataClasificationComponent implements OnInit 
{
  

  public path: string= undefined;
  public generatedTag: string= undefined;

  constructor(private commonSerrvice: CommonDataService ) { }

  ngOnInit() { }

  pageStatus()
  {
    if(this.path)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  collectData()
  {
    this.path= undefined;
  }

}
