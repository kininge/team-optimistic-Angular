import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonDataService } from 'src/modules/app/services/common-data.service';

@Component({
  selector: 'app-data-collection',
  templateUrl: './data-collection.component.html',
  styleUrls: ['./data-collection.component.scss']
})
export class DataCollectionComponent implements OnInit 
{
  public collectionType: string= 'image';
  public response: boolean= false;

  public images: string= undefined;
  public imagesList: string[]= [];
  public saveAnnotations: boolean= false;

  public apiUrl: string= undefined;
  public parameter: string= undefined;

  constructor(private httpClient: HttpClient, private commonSerrvice: CommonDataService ) { }

  ngOnInit() { }

  getImage()
  {
    this.imagesList= [];

    if(this.images!= undefined)
    {
      this.imagesList= this.images.trim().split(', ');
    }
  }

  pageStatus()
  {
    if(this.collectionType== 'url')
    {
      if(this.apiUrl && this.parameter)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    else
    {
      if(this.imagesList.length> 0)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }

  async collectData()
  {
    if(this.collectionType== 'image')
    {
      console.log('Running URL: '+this.commonSerrvice.getBaseURL()+'download/openImages/');
      await this.httpClient.post<any>(this.commonSerrvice.getBaseURL()+'download/openImages/', 
      { "classList": this.imagesList, "saveAnnotation": this.saveAnnotations })
      .subscribe
      (
        result=>
        {
          console.log(result);
        },
        error=>
        {
          console.log(error);
        }
      );
    }

    this.images= undefined;
    this.imagesList= [];
    this.saveAnnotations= false;
    this.apiUrl= undefined;
    this.parameter= undefined;
  }

}
